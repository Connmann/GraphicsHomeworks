# Homework 2 - Lorenz Attractor
## Connor Guerin

## Instructions
`s`, `b`, `r` => Select the variable to modify. The selected variable will highlight on the screen.
`[`, `]` => Increment/decrement the selected variable by 0.1. This will update the Lorenz Attractor that is displayed.

`Arrow Keys` => Rotate the view of the Lorenz Attractor.

##Time to Complete
This entire assignment took about 3 hours to complete.
