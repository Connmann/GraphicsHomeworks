#Final Project

##Connor Guerin
The project is meant to run in first person (the camera pans but there is no player movement). Press p to switch to perspective 'flying' camera for closer inspection/grading purposes. The day night cycle takes 36 seconds (10 degrees/sec) to do a complete cycle.

##Key Bindings
m          Toggles light (sun) movement
p          Toggles first person/perspective projection
+/-        Change field of view of perspective
x          Toggle axes display
arrow keys Change view angle
PgDn/PgUp  Zoom in and out (in perspective view)
0          Reset view angle
ESC        Exit

